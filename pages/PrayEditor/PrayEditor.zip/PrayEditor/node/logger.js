/* jshint esversion: 7 */
/*jshint -W069 */
var logger = {
  level:4,
  output:true,
  info(text){
    if (this.level>=1 && this.output == true){
      console.log(`\x1b[92m${now()} \x1b[96mINFO [祈愿] \x1b[92m${text}\x1b[0m`);     
    }
  },
  warn(text){
    if (this.level>=2 && this.output == true){
      console.log(`\x1b[92m${now()} \x1b[93mWARN [祈愿] ${text}\x1b[0m`);
    }
    
  },
  error(text){
    if (this.level>=3 && this.output == true){
      console.log(`\x1b[92m${now()} \x1b[91mERROR [祈愿] ${text}\x1b[0m`);
    }
    
  },
  fatal(text){
    if (this.level>=4 && this.output == true){
      console.log(`\x1b[92m${now()} \x1b[31mFATAL [祈愿] ${text}\x1b[0m`);
    }
    
  },
  debug(text){
    if (this.level>=5 && this.output == true){
      console.log(`\x1b[92m${now()} \x1b[0mDEBUG [祈愿] ${text}\x1b[0m`);
    }
  },
  setConsole(output, lev){
    if (!(/(^[2-5]$)/.test(lev))){
      console.log(`\x1b[92m${now()} \x1b[91mERROR [祈愿] Logger等级须为2-5的正整数\x1b[0m`);
      return false;
    }
    this.level = Number(lev);
    this.output = output;
    //this.warn(`日志等级调整为: ${this.level}`);
    return true;
  },

  query(){
  return this.level;
  }
  
};


function now(){
  let date = new Date();
  return [date.toTimeString().slice(0, 8)].join('');
}

module.exports = logger;
