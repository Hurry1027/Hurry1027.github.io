const fs = require('fs');
const path = require('path');

var file = {
    read(filePath){
        return fs.readFileSync(filePath, {encoding:'utf-8'}).toString();
    },
    write(filePath, content){
        return fs.writeFileSync(filePath, content);
    },
    delete(filePath){
        return fs.unlinkSync(filePath);
    },
    rename(filePath, newFileName){
        return fs.renameSync(filePath,`${path.parse(filePath).dir}/${newFileName}`);
    },
    copy(filePath, newFilePath){
        return fs.copyFileSync(filePath, newFileName);
    },

    async readAsync(filePath){
        return new Promise((resolve, reject) => {
            fs.readFile(filePath, {encoding:'utf-8'}, (err, data)=>{
                if (err) {
                    console.error(err);
                    resolve(null);
                }else{
                    resolve(data.toString());
                }
            });
        });
    },
    async writeAsync(filePath, content){
        return new Promise((resolve, reject) => {
            fs.writeFile(filePath, content,  (err)=>{
                if (err) {
                    console.error(err);
                    resolve(false);
                }else{
                    resolve(true);
                }
            });
        });
        
    },
    async deleteAsync(filePath){
        return new Promise((resolve, reject) => {
            fs.unlinkSync(filePath, (err)=>{  
                if (err) {
                    console.error(err);
                    resolve(false);
                }else{
                    resolve(true);
                }
            });
        });
    },
    async renameAsync(filePath, newFileName){
        return new Promise((resolve, reject) => {
            fs.rename(filePath, `${path.parse(filePath).dir}/${newFileName}`, (err)=>{  
                if (err) {
                    console.error(err);
                    resolve(false);
                }else{
                    resolve(true);
                }
            });
        });
    },
    async copyAsync(){
        return new Promise((resolve, reject) => {
            fs.copyFile(filePath, newFileName, (err)=>{
                if (err) {
                    console.error(err);
                    resolve(false);
                }else{
                    resolve(true);
                }
            });
        });
    }
};