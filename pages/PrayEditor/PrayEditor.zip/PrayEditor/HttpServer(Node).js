const http = require('http');
const fs = require('fs');
const url = require('url');
const logger = require('./node/logger.js');
// const querystring = require('node:querystring'); 

const Port = 7100; // http端口

if (!(/\\plugins\\LuckyPray\\/.test(__dirname))){
    logger.error('请将PrayEditor文件夹放到BDS根目录./plugins/LuckPray/文件夹下');
    console.log('--- Quit ---');
    process.exit(0);
}


let server = http.createServer((req, res) => {
    let method = req.method.toLowerCase();
   
    if (method == 'get'){
        let params = url.parse(req.url, true).query;
        let pathname = url.parse(req.url, true).pathname;
        if (pathname == "/"){
            res.statusCode = 301;// 301永久重定向 302临时重定向
            res.setHeader('Location','/index.html');
            res.end();
            return;
        }
        if (pathname == "/LuckyPray/"){
            if (['Config', 'CardPool', 'SNBTdata'].includes(params.getJson)){
                fs.readFile(`../${params.getJson}.json`, (err, data)=>{
                    if (err){
                        returnFile(`./public${pathname}`);
                        return;
                    }
                    res.write(data.toString());
                    res.end();
                    return;
                });
                return;
            }
        }
        
        return returnFile(`./public${pathname}`);
    }else if (method == 'post'){
        // POST 请求
        parsePost(req, res, '/LuckyPray/', (req, res, POST)=>{
            try{
                POST = JSON.parse(POST);
                if (['Config', 'CardPool', 'SNBTdata'].includes(POST.purpose)){
                    fs.writeFile(`../${POST.purpose}.json`, JSON.stringify(POST.data, null, 4), (err)=>{
                        if (err) {
                            console.error(err);
                            res.write(`<span style="color:red;">✕保存${POST.purpose}.json失败&nbsp;<span><span style="color:gray;">(${nowDateStr()})<span>`);
                            logger.error(`✕保存${POST.purpose}.json失败 (${nowDateStr()})`);
                            res.end();
                        }else{
                            res.write(`<span style="color:green;">√保存${POST.purpose}.json成功&nbsp;<span><span style="color:gray;">(${nowDateStr()})<span>`);
                            logger.info(`√保存${POST.purpose}.json成功 (${nowDateStr()})`);
                            res.end();
                        }
                    });
                }else{
                    //console.log(POST)
                }
            }catch(e){
                //console.log(e)
                return;
            }
            
            return;
        });
    }

    //静态资源请求
    function returnFile(url){
        readFile(url).then((data) => {
            res.write(data, "binary");
            res.end();
        }, (err)=>{
            res.setHeader('content-type','text/html; charset=utf-8');
            res.statusCode = 404;
            res.end('404 Not Found | 你要找的不存在哦！');
            return;
        });
    }
});

function parseGet(req, res){
    var obj = urlLib.parse(req.url, true);
    var url = obj.pathname;
    return obj.query;
}

function parsePost(req, res, url, callback){
    if (req.url != url){return;}
    var str = '';
    var POST = '';
    req.on('data', function(data) {
        str += data;
    });
    req.on('end', function() {
        POST = str;
        // POST = querystring.parse(str);
        callback(req, res, POST);
    });
    return;
}


function nowDateStr(){
    let date = new Date();
    return `${date.getFullYear()}-${date.getMonth()+1}-${date.getDate()}-${date.getHours()}-${date.getMinutes()}-${date.getSeconds()}`;
}


function readFile (filePath) {
    return new Promise((resolve, reject) => {
        fs.readFile(filePath, "binary", (err, data) => {
            if(err) {
                reject(err);
                return;
            }
            resolve(data);
        });
    });
}
 
server.listen(Port, () => {
    console.log(`======================================`);
    console.log(`【祈愿编辑器】Chrome访问 http://localhost:${Port}`);
    console.log(`> Web HTTP服务器已在 ${Port}端口 开启`);
    console.log(`> 放开防火墙 TCP${Port}端口 后可公网访问(不建议)`);
    console.log(`> re: 重启HTTP服务端`);
    console.log(`> stop: 关闭HTTP服务端`);
    console.log(`======================================`);
});



//==========================================================================================
//==========================================================================================
//==========================================================================================
//==========================================================================================
consoleInput();
function consoleInput(){
    process.stdin.resume();
    process.stdin.setEncoding('utf8');
    process.stdin.on('data', function (text) {
        var cmd = text.split(/\s+/)[0];
        var args = text.split(/\s+/).slice(1);
        switch (cmd){
            case 'stop':
                done();
                break;
            case 're':
                process.exit(2);
                break;
        }       
    });

    function done() {
      console.log('--- Quit ---');
      process.exit(0);
    }
} 