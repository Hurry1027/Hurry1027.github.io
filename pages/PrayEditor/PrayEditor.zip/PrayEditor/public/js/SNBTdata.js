const SNBTdata_default = {
    "三星": {
        "经验修补": {
            "discription": "经验修补附魔书",
            "snbt": "{\"Count\":1b,\"Damage\":0s,\"Name\":\"minecraft:enchanted_book\",\"WasPickedUp\":0b,\"tag\":{\"ench\":[{\"id\":26s,\"lvl\":1s}]}}"
        },
        "原石": {
            "discription": "1个",
            "snbt": "{\"Count\":1b,\"Damage\":0s,\"Name\":\"minecraft:nether_star\",\"WasPickedUp\":0b,\"tag\":{\"ench\":[],\"RepairCost\":0,\"display\":{\"Name\":\"§r§b◇原石◇\", \"Lore\": [\"§r§6古代遗迹中的石头\"]}}}"
        }
    },
    "二星": {
        "夜视药水8": {
            "discription": "直接喝的8分钟",
            "snbt": "{\"Count\":1b,\"Damage\":6s,\"Name\":\"minecraft:potion\",\"WasPickedUp\":0b}"
        }
    }    
};